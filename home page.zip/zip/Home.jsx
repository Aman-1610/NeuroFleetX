import { useState } from 'react'
import '../styles/Home.css'

function Home({ onLogout }) {
  const [candyCount, setCandyCount] = useState(0)

  return (
    <div className="home-container">

      <nav className="navbar">
        <div className="nav-content">
          <div className="logo">🎃 NeuroFleetX</div>
          <button className="logout-btn" onClick={onLogout}>Logout</button>
        </div>
      </nav>

      <section className="hero">
        
        <div className="floating-pumpkins">
          <span className="pumpkin">🎃</span>
          <span className="pumpkin">👻</span>
          <span className="pumpkin">🦇</span>
          <span className="pumpkin">🕷️</span>
          <span className="pumpkin">🎃</span>
          <span className="pumpkin">👻</span>
        </div>

        <div className="hero-content">
          <h1 className="hero-title">Welcome to Halloween Party 🎃</h1>
        </div>
      </section>

      <section className="features">
        <div className="features-grid">

          <div className="feature-card">
            <div className="feature-icon">🎨</div>
            <h3>Colorful Pictures</h3>
            <p>Use colorful icons, emojis, Halloween-themed graphics.</p>
          </div>

          <div className="feature-card">
            <div className="feature-icon">🎃</div>
            <h3>Halloween Theme</h3>
            <p>Spooky style, orange-glow cards & floating animations.</p>
          </div>

          <div className="feature-card">
            <div className="feature-icon">🎉</div>
            <h3>Party Vibes</h3>
            <p>A fun, engaging homepage filled with festival energy.</p>
          </div>

          <div className="feature-card">
            <div className="feature-icon">✨</div>
            <h3>Special Effects</h3>
            <p>Smooth animations, hover effects, and glowing UI.</p>
          </div>

        </div>
      </section>

      <section className="interactive">
        <div className="interactive-content">
          <h2>Collect Halloween Candy 🍬</h2>
          <p className="candy-counter">Total Candy Collected: {candyCount}</p>

          <button
            className="candy-btn"
            onClick={() => setCandyCount(candyCount + 1)}
          >
            🍭 Trick or Treat
          </button>

        </div>
      </section>

      <footer className="footer">
        <p>&copy; 2024 NeuroFleetX Halloween Party. Happy Halloween 🎃👻</p>
      </footer>

    </div>
  )
}

export default Home
